"""
Tu dong lay:
  1. PMI Vietnam (S&P Global Manufacturing PMI) — monthly 2013+
  2. Foreign net flow HOSE (giao dich rong khoi ngoai) — daily 2013+

Chay: python fetch_pmi_and_flow.py
Ket qua luu vao ../data/ roi tu dong merge.
"""
from __future__ import annotations
import io, json, time, datetime as dt, sys
from pathlib import Path

import pandas as pd
import requests

DATA  = Path(__file__).resolve().parent.parent / "data"
DATA.mkdir(exist_ok=True)

START = "2013-01-01"
END   = dt.date.today().isoformat()

SESS = requests.Session()
SESS.headers.update({
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                  "AppleWebKit/537.36 (KHTML, like Gecko) "
                  "Chrome/124.0.0.0 Safari/537.36",
    "Accept-Language": "vi-VN,vi;q=0.9,en;q=0.8",
})


# ═══════════════════════════════════════════════════════════════════════════════
# PART 1 — PMI VIETNAM
# ═══════════════════════════════════════════════════════════════════════════════

def _pmi_macrotrends() -> pd.Series | None:
    """Macrotrends.net — Vietnam Manufacturing PMI (co data tu 2013)."""
    url = "https://www.macrotrends.net/assets/php/fundamental_iframe.php"
    params = {"t": "VNM", "type": "manufacturing-pmi",
              "statement": "balance-sheet", "frequency": "Q"}
    try:
        r = SESS.get(url, params=params, timeout=15)
        if r.status_code != 200:
            return None
        # Data nam trong JSON trong <script>
        import re
        m = re.search(r'var chartData\s*=\s*(\[.*?\]);', r.text, re.S)
        if not m:
            m = re.search(r'"data"\s*:\s*(\[\[.*?\]\])', r.text, re.S)
        if m:
            rows = json.loads(m.group(1))
            if rows and isinstance(rows[0], list):
                dates = pd.to_datetime([r[0] for r in rows])
                vals  = [r[1] for r in rows]
            else:
                dates = pd.to_datetime([r.get("date") for r in rows])
                vals  = [r.get("value") or r.get("val") for r in rows]
            s = pd.Series(vals, index=dates, name="pmi").dropna().sort_index()
            s.index.name = "date"
            if len(s) > 10:
                return s
    except Exception as e:
        print(f"   macrotrends ERR: {e}")
    return None


def _pmi_macrotrends_html() -> pd.Series | None:
    """Macrotrends — scrape bang HTML."""
    url = "https://www.macrotrends.net/countries/VNM/vietnam/manufacturing-pmi"
    try:
        r = SESS.get(url, timeout=15)
        if r.status_code != 200:
            return None
        import re
        # Tim JSON data trong script
        m = re.search(r'var originalData\s*=\s*(\[.*?\]);', r.text, re.S)
        if not m:
            m = re.search(r'chartData\s*=\s*(\[.*?\])', r.text, re.S)
        if m:
            rows = json.loads(m.group(1))
            if rows:
                if isinstance(rows[0], dict):
                    dates = pd.to_datetime([x.get("date","") for x in rows])
                    vals  = [float(str(x.get("value","")).replace(",","") or "nan")
                             for x in rows]
                else:
                    dates = pd.to_datetime([x[0] for x in rows])
                    vals  = [x[1] for x in rows]
                s = pd.Series(vals, index=dates, name="pmi").dropna().sort_index()
                s.index.name = "date"
                if len(s) > 10:
                    return s
        # Fallback: read_html
        tables = pd.read_html(io.StringIO(r.text))
        for t in tables:
            cols = [str(c).lower() for c in t.columns]
            if any("pmi" in c or "value" in c for c in cols):
                date_c = next((c for c in t.columns if "date" in str(c).lower()), None)
                val_c  = next((c for c in t.columns
                               if any(k in str(c).lower() for k in ["value","pmi","actual"])), None)
                if date_c and val_c:
                    s = pd.Series(
                        pd.to_numeric(t[val_c].astype(str).str.replace(",",""), errors="coerce").values,
                        index=pd.to_datetime(t[date_c], errors="coerce"),
                        name="pmi"
                    ).dropna().sort_index()
                    s.index.name = "date"
                    if len(s) > 10:
                        return s
    except Exception as e:
        print(f"   macrotrends html ERR: {e}")
    return None


def _pmi_investing_chart() -> pd.Series | None:
    """Investing.com chart API — thu lai voi pointscount lon hon."""
    try:
        SESS.get("https://vn.investing.com/", timeout=10)
    except Exception:
        pass
    for points in [500, 200, 120]:
        url = (f"https://api.investing.com/api/financialdata/1210"
               f"/historical/chart/?period=MAX&startDate={START}&endDate={END}"
               f"&pointscount={points}")
        try:
            r = SESS.get(url, headers={
                "Accept": "application/json",
                "Referer": "https://vn.investing.com/",
                "X-Requested-With": "XMLHttpRequest",
            }, timeout=20)
            if r.status_code == 200:
                data = r.json().get("data", [])
                if data:
                    df = pd.DataFrame(data)
                    ts  = pd.to_datetime(df[0], unit="ms")
                    val = pd.to_numeric(df[4] if len(df.columns) > 4 else df[1],
                                        errors="coerce")
                    s = pd.Series(val.values, index=ts, name="pmi").dropna().sort_index()
                    s.index.name = "date"
                    if len(s) > 10:
                        return s
        except Exception as e:
            print(f"   investing chart (points={points}) ERR: {e}")
    return None


def _pmi_trading_economics() -> pd.Series | None:
    """Trading Economics — scrape bang historical."""
    url = "https://tradingeconomics.com/vietnam/manufacturing-pmi"
    try:
        r = SESS.get(url, timeout=15)
        if r.status_code != 200:
            return None
        import re
        # Tim JSON trong script tag
        m = re.search(r'var historicalData\s*=\s*(\[.*?\])\s*;', r.text, re.S)
        if not m:
            m = re.search(r'"historical"\s*:\s*(\[.*?\])', r.text, re.S)
        if m:
            rows = json.loads(m.group(1))
            dates = pd.to_datetime([x.get("Date") or x.get("date","") for x in rows])
            vals  = [x.get("Value") or x.get("value") for x in rows]
            s = pd.Series(vals, index=dates, name="pmi").dropna().sort_index()
            s.index.name = "date"
            if len(s) > 10:
                return s
        # read_html fallback
        tables = pd.read_html(io.StringIO(r.text))
        for t in tables:
            if len(t) > 12:
                cols_low = [str(c).lower() for c in t.columns]
                date_c = next((t.columns[i] for i, c in enumerate(cols_low)
                               if "date" in c or "period" in c or "month" in c), None)
                val_c  = next((t.columns[i] for i, c in enumerate(cols_low)
                               if "actual" in c or "value" in c or "pmi" in c), None)
                if date_c and val_c:
                    s = pd.Series(
                        pd.to_numeric(t[val_c].astype(str).str.replace(",",""), errors="coerce").values,
                        index=pd.to_datetime(t[date_c], errors="coerce"),
                        name="pmi"
                    ).dropna().sort_index()
                    s.index.name = "date"
                    if len(s) > 10:
                        return s
    except Exception as e:
        print(f"   trading economics ERR: {e}")
    return None


def _pmi_theglobaleconomy() -> pd.Series | None:
    """TheGlobalEconomy.com — free PMI data, no login required."""
    import re
    url = "https://www.theglobaleconomy.com/Vietnam/PMI/"
    try:
        r = SESS.get(url, timeout=15)
        if r.status_code != 200:
            return None
        # Tim data trong script JSON
        m = re.search(r"data\s*:\s*\[(\[.*?\])\]", r.text, re.S)
        if m:
            rows = json.loads("[" + m.group(1) + "]")
            # Format: [[year, value], ...]  hoac  [[date_str, value], ...]
            dates, vals = [], []
            for row in rows:
                if len(row) >= 2:
                    try:
                        dates.append(pd.to_datetime(str(row[0])))
                        vals.append(float(row[1]))
                    except Exception:
                        pass
            if len(dates) > 10:
                s = pd.Series(vals, index=dates, name="pmi").dropna().sort_index()
                s.index.name = "date"
                return s
        # Fallback: CSV download endpoint
        csv_url = "https://www.theglobaleconomy.com/download_data.php?country=Vietnam&indicator=PMI"
        r2 = SESS.get(csv_url, timeout=15)
        if r2.status_code == 200 and "," in r2.text:
            df = pd.read_csv(io.StringIO(r2.text))
            date_c = next((c for c in df.columns if "year" in c.lower() or "date" in c.lower()), df.columns[0])
            val_c  = next((c for c in df.columns if "pmi" in c.lower() or "value" in c.lower()), df.columns[-1])
            s = pd.Series(
                pd.to_numeric(df[val_c], errors="coerce").values,
                index=pd.to_datetime(df[date_c].astype(str), errors="coerce"),
                name="pmi"
            ).dropna().sort_index()
            s.index.name = "date"
            if len(s) > 10:
                return s
    except Exception as e:
        print(f"   theglobaleconomy ERR: {e}")
    return None


def _pmi_worldbank_proxy() -> pd.Series | None:
    """
    WorldBank — khong co PMI truc tiep, nhung co Industrial Production Index
    (IP.IND.INPT.KD) lam proxy gan nhat. Monthly (some countries), annual (VN).
    Chi dung neu khong co nguon nao khac.
    """
    for indicator in ["IP.IND.INPT.KD", "NV.IND.MANF.KD", "NV.IND.MANF.ZS"]:
        url = (f"https://api.worldbank.org/v2/country/VN/indicator/{indicator}"
               f"?format=json&per_page=50&date=2013:2025")
        try:
            r = SESS.get(url, timeout=15)
            if r.status_code == 200:
                d = r.json()
                if len(d) > 1 and d[1]:
                    rows = [(x["date"], x["value"]) for x in d[1]
                            if x["value"] is not None]
                    if len(rows) > 5:
                        s = pd.Series({y: v for y, v in rows})
                        s.index = pd.to_datetime([f"{y}-06-30" for y in s.index])
                        s = s.resample("ME").interpolate("linear")
                        s.name = "pmi_proxy_wb"
                        s.index.name = "date"
                        print(f"   WB {indicator}: {len(rows)} annual obs (proxy, not real PMI)")
                        return s
        except Exception:
            pass
    return None


def get_pmi() -> pd.Series | None:
    print("\n[PMI] Thu cac nguon tu dong...")
    for name, fn in [
        ("Investing.com chart API",   _pmi_investing_chart),
        ("TheGlobalEconomy.com",      _pmi_theglobaleconomy),
        ("Trading Economics",          _pmi_trading_economics),
        ("Macrotrends.net (JSON)",    _pmi_macrotrends),
        ("Macrotrends.net (HTML)",    _pmi_macrotrends_html),
    ]:
        print(f"  > {name}...")
        s = fn()
        if s is not None and len(s) >= 12:
            s = s.loc[START:END]
            print(f"  OK: {len(s)} obs | {s.index[0].date()} -> {s.index[-1].date()}")
            return s
        print(f"    Khong co data.")
        time.sleep(0.5)
    return None


# ═══════════════════════════════════════════════════════════════════════════════
# PART 2 — FOREIGN NET FLOW HOSE
# ═══════════════════════════════════════════════════════════════════════════════

def _flow_simplize() -> pd.DataFrame | None:
    """Simplize public API — foreign trading toan thi truong."""
    base = "https://api2.simplize.vn/api/market/foreign-trading"
    start_dt = pd.Timestamp(START)
    end_dt   = pd.Timestamp(END)
    chunks   = []
    cur = start_dt
    while cur <= end_dt:
        nxt = min(cur + pd.DateOffset(years=1), end_dt)
        url = f"{base}?type=net&from={cur.date()}&to={nxt.date()}&exchange=HOSE"
        try:
            r = SESS.get(url, timeout=15)
            if r.status_code == 200:
                d = r.json()
                items = d if isinstance(d, list) else d.get("data", [])
                if items:
                    df = pd.DataFrame(items)
                    chunks.append(df)
        except Exception:
            pass
        cur = nxt + pd.DateOffset(days=1)
        time.sleep(0.3)
    if chunks:
        return pd.concat(chunks, ignore_index=True)
    return None


def _flow_tcbs() -> pd.DataFrame | None:
    """TCBS public API — foreign trading."""
    base = "https://apipubaws.tcbs.com.vn/stock-insight/v1/market/foreign-trading"
    chunks = []
    cur = pd.Timestamp(START)
    end = pd.Timestamp(END)
    while cur <= end:
        nxt = min(cur + pd.DateOffset(months=6), end)
        url = f"{base}?fromDate={cur.date()}&toDate={nxt.date()}"
        try:
            r = SESS.get(url, timeout=15)
            if r.status_code == 200:
                d = r.json()
                items = d.get("data", d) if isinstance(d, dict) else d
                if isinstance(items, list) and items:
                    chunks.append(pd.DataFrame(items))
        except Exception:
            pass
        cur = nxt + pd.DateOffset(days=1)
        time.sleep(0.3)
    if chunks:
        return pd.concat(chunks, ignore_index=True)
    return None


def _flow_vci() -> pd.DataFrame | None:
    """VCI Securities API (backend of vnstock)."""
    headers = {
        **dict(SESS.headers),
        "Accept": "application/json",
        "Origin": "https://vietcap.com.vn",
        "Referer": "https://vietcap.com.vn/",
    }
    base = "https://mt.vci.com.vn/v2/market/foreign-trading"
    chunks = []
    cur = pd.Timestamp(START)
    end = pd.Timestamp(END)
    while cur <= end:
        nxt = min(cur + pd.DateOffset(months=3), end)
        params = {"startDate": str(cur.date()), "endDate": str(nxt.date()),
                  "market": "HOSE"}
        try:
            r = SESS.get(base, params=params, headers=headers, timeout=15)
            if r.status_code == 200:
                d = r.json()
                items = d.get("data", d) if isinstance(d, dict) else d
                if isinstance(items, list) and items:
                    chunks.append(pd.DataFrame(items))
        except Exception:
            pass
        cur = nxt + pd.DateOffset(days=1)
        time.sleep(0.2)
    if chunks:
        return pd.concat(chunks, ignore_index=True)
    return None


def _flow_ssi_iboard() -> pd.DataFrame | None:
    """SSI iBoard API — market foreign activity."""
    try:
        SESS.get("https://iboard.ssi.com.vn/", timeout=10)
    except Exception:
        pass
    from_ts = int(pd.Timestamp(START).timestamp())
    to_ts   = int(pd.Timestamp(END).timestamp())
    for url in [
        f"https://iboard-query.ssi.com.vn/v2/stock/foreign-activity?market=HOSE&from={from_ts}&to={to_ts}",
        f"https://iboard-query.ssi.com.vn/v2/market/foreign?from={from_ts}&to={to_ts}&exchange=HOSE",
    ]:
        try:
            r = SESS.get(url, timeout=15)
            if r.status_code == 200:
                d = r.json()
                items = d.get("data", d) if isinstance(d, dict) else d
                if isinstance(items, list) and len(items) > 5:
                    return pd.DataFrame(items)
        except Exception:
            pass
    return None


def _normalize_flow(df: pd.DataFrame) -> pd.DataFrame | None:
    """Chuan hoa DataFrame thanh: date, foreign_buy_value, foreign_sell_value, foreign_net_value."""
    if df is None or df.empty:
        return None
    df.columns = [str(c).lower().strip() for c in df.columns]
    # Tim cot date
    date_col = next((c for c in df.columns
                     if any(k in c for k in ["date","time","ngay","trad"])), None)
    if date_col is None and df.index.name and "date" in str(df.index.name).lower():
        df = df.reset_index()
        date_col = df.columns[0]
    if date_col is None:
        # Thu cot dau tien co kieu date
        for c in df.columns:
            try:
                parsed = pd.to_datetime(df[c], errors="coerce")
                if parsed.notna().mean() > 0.5:
                    date_col = c
                    break
            except Exception:
                pass
    if date_col is None:
        return None

    # Tim cac cot buy/sell/net
    buy_col  = next((c for c in df.columns if any(k in c for k in
                     ["buy","mua","buyvalue","buy_val","foreignbuy"])), None)
    sell_col = next((c for c in df.columns if any(k in c for k in
                     ["sell","ban","sellvalue","sell_val","foreignsell"])), None)
    net_col  = next((c for c in df.columns if any(k in c for k in
                     ["net","rong","netvalue","net_val","foreignnet"])), None)

    out = pd.DataFrame()
    out["date"] = pd.to_datetime(df[date_col], errors="coerce")
    for src, dst in [(buy_col,"foreign_buy_value"),
                     (sell_col,"foreign_sell_value"),
                     (net_col,"foreign_net_value")]:
        if src:
            out[dst] = pd.to_numeric(
                df[src].astype(str).str.replace(",",""), errors="coerce")

    # Neu co buy va sell nhung khong co net, tinh net
    if "foreign_buy_value" in out and "foreign_sell_value" in out \
            and "foreign_net_value" not in out:
        out["foreign_net_value"] = out["foreign_buy_value"] - out["foreign_sell_value"]

    out = out.dropna(subset=["date"]).set_index("date").sort_index()
    out.index.name = "date"
    return out if len(out) > 10 else None


def get_foreign_flow() -> pd.DataFrame | None:
    print("\n[Foreign flow] Thu cac nguon tu dong...")
    for name, fn in [
        ("Simplize API",   _flow_simplize),
        ("TCBS public API",_flow_tcbs),
        ("VCI API",        _flow_vci),
        ("SSI iBoard",     _flow_ssi_iboard),
    ]:
        print(f"  > {name}...")
        try:
            raw = fn()
            df  = _normalize_flow(raw)
            if df is not None and "foreign_net_value" in df.columns:
                df = df.loc[START:END]
                nn = df["foreign_net_value"].notna().sum()
                print(f"  OK: {nn:,} obs | {df.index[0].date()} -> {df.index[-1].date()}")
                return df
        except Exception as e:
            print(f"    ERR: {type(e).__name__}: {str(e)[:80]}")
        print(f"    Khong co data.")
        time.sleep(0.5)
    return None


# ═══════════════════════════════════════════════════════════════════════════════
# MAIN
# ═══════════════════════════════════════════════════════════════════════════════

def main():
    saved_any = False

    # ── PMI ──────────────────────────────────────────────────────────────────
    pmi = get_pmi()
    if pmi is not None:
        out = DATA / "pmi_vietnam_raw.csv"
        pmi.to_csv(out, header=True)
        print(f"\n  Saved: {out.name}  ({len(pmi)} rows)")
        saved_any = True
    else:
        print("\n[PMI] Tat ca nguon tu dong that bai.")
        print("  Tai thu cong:")
        print("  1. Vao: https://vn.investing.com/economic-calendar/vietnam-manufacturing-pmi-1210")
        print("  2. Keo xuong bang lich su -> Tai xuong du lieu")
        print(f"  3. Luu vao: {DATA / 'pmi_vietnam_raw.csv'}")

    time.sleep(1)

    # ── Foreign flow ─────────────────────────────────────────────────────────
    ff = get_foreign_flow()
    if ff is not None:
        out = DATA / "foreign_net_flow_hose_daily.csv"
        ff.to_csv(out)
        print(f"\n  Saved: {out.name}  ({len(ff)} rows)")
        saved_any = True
    else:
        print("\n[Foreign flow] Tat ca nguon tu dong that bai.")
        print("  Tai thu cong:")
        print("  1. Vao: https://www.hsx.vn/Modules/Rsde/Report/ForeignTradingReportIndex")
        print("  2. Chon VNINDEX -> Export tung doan 5 nam")
        print(f"  3. Luu vao: {DATA / 'foreign_net_flow_hose_daily.csv'}")

    # ── Merge ─────────────────────────────────────────────────────────────────
    if saved_any:
        print("\n>>> Chay merge_manual_data.py ...")
        import subprocess, os
        subprocess.run(
            [sys.executable, str(Path(__file__).parent / "merge_manual_data.py")],
            env={**os.environ, "PYTHONIOENCODING": "utf-8", "PYTHONUTF8": "1"},
        )
    else:
        print("\nKhong co du lieu moi. Merge bi bo qua.")


if __name__ == "__main__":
    main()
