"""
================================================================================
 Merge thủ công: PMI Vietnam + Interbank Rate -> macro_*_merged.csv
================================================================================
 Hướng dẫn tải thủ công từ Investing.com:

 [PMI Vietnam]
   1. Vào: https://vn.investing.com/economic-calendar/vietnam-manufacturing-pmi-1210
   2. Kéo xuống phần bảng lịch sử → nhấn nút "Tải xuống dữ liệu" (Download Data)
   3. Lưu file vào: <DATA_DIR>/pmi_vietnam_raw.csv

 [Interbank rate ON (qua đêm) - SBV]
   Cách 1 – Investing.com:
   1. Vào: https://vn.investing.com/rates-bonds/vietnam-interbank-rate
   2. Bảng lịch sử → "Tải xuống" → lưu vào: <DATA_DIR>/interbank_raw.csv
   Cách 2 – SBV trực tiếp:
   1. Vào: https://www.sbv.gov.vn/webcenter/portal/vi/menu/rm/tttc/tttt
   2. Chọn loại lãi suất liên ngân hàng → xuất Excel → đổi sang CSV

 Script này tự phát hiện format và chuẩn hoá.
================================================================================
"""

from __future__ import annotations
import sys
import io
import datetime as dt
from pathlib import Path

import pandas as pd
import numpy as np

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "data"


# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────

def _read_investing_csv(path: Path, value_col_hint: str = "Price") -> pd.Series:
    """
    Đọc CSV xuất từ Investing.com.
    Format header: "Date","Price","Open","High","Low","Change %"
    Date có thể là "Jan 2024" (monthly) hoặc "01/15/2024" (daily).
    """
    raw = pd.read_csv(path, thousands=",", encoding="utf-8-sig")
    raw.columns = raw.columns.str.strip().str.replace('"', '')

    # Tìm cột date
    date_col = next((c for c in raw.columns if "date" in c.lower()), raw.columns[0])
    # Tìm cột giá trị
    val_col  = next((c for c in raw.columns if value_col_hint.lower() in c.lower()),
                    raw.columns[1])

    dates = pd.to_datetime(raw[date_col], dayfirst=False, errors="coerce")
    values = pd.to_numeric(raw[val_col].astype(str).str.replace(",", ""), errors="coerce")

    s = pd.Series(values.values, index=dates, name=path.stem)
    s = s.dropna()
    s.index.name = "date"
    return s.sort_index()


def _read_sbv_csv(path: Path) -> pd.Series:
    """
    Đọc CSV / Excel từ SBV.
    Cố gắng tự phát hiện cột ngày và cột giá trị.
    """
    if path.suffix.lower() in (".xlsx", ".xls"):
        raw = pd.read_excel(path, header=0)
    else:
        raw = pd.read_csv(path, encoding="utf-8-sig", thousands=",")

    raw.columns = raw.columns.str.strip()

    # Tìm cột date (thử từng cột)
    date_col, val_col = None, None
    for c in raw.columns:
        try:
            parsed = pd.to_datetime(raw[c], errors="coerce")
            if parsed.notna().mean() > 0.5:
                date_col = c
                break
        except Exception:
            pass
    # Tìm cột số đầu tiên sau date_col
    for c in raw.columns:
        if c == date_col:
            continue
        nums = pd.to_numeric(raw[c].astype(str).str.replace(",", ""), errors="coerce")
        if nums.notna().mean() > 0.5:
            val_col = c
            break

    if date_col is None or val_col is None:
        raise ValueError(f"Không tìm thấy cột date/value trong {path}. "
                         f"Columns: {raw.columns.tolist()}")

    dates  = pd.to_datetime(raw[date_col], errors="coerce")
    values = pd.to_numeric(raw[val_col].astype(str).str.replace(",", ""), errors="coerce")
    s = pd.Series(values.values, index=dates, name=path.stem)
    s = s.dropna().sort_index()
    s.index.name = "date"
    return s


def load_series(path: Path, col_name: str) -> pd.Series:
    """Đọc file (tự phát hiện nguồn) và trả về Series tên col_name."""
    print(f"  Đọc: {path.name}")
    try:
        s = _read_investing_csv(path)
    except Exception:
        s = _read_sbv_csv(path)
    s.name = col_name
    print(f"  -> {len(s):,} dòng  |  {s.index[0].date()} → {s.index[-1].date()}")
    return s


# ─────────────────────────────────────────────────────────────────────────────
# Main merge
# ─────────────────────────────────────────────────────────────────────────────

def main():
    pmi_path  = DATA / "pmi_vietnam_raw.csv"
    ibor_path = DATA / "interbank_raw.csv"   # hoặc .xlsx

    # Cho phép tên file khác nếu có
    if not pmi_path.exists():
        candidates = list(DATA.glob("pmi*.*"))
        if candidates:
            pmi_path = candidates[0]
    if not ibor_path.exists():
        candidates = list(DATA.glob("interbank*.*"))
        if candidates:
            ibor_path = candidates[0]

    loaded = {}

    # ── Load PMI ──────────────────────────────────────────────────────────────
    if pmi_path.exists():
        print("\n[PMI] Đang xử lý...")
        pmi = load_series(pmi_path, "pmi")
        pmi.to_csv(DATA / "pmi_vietnam_monthly.csv", header=True)
        print(f"  Đã lưu: pmi_vietnam_monthly.csv")
        loaded["pmi"] = pmi
    else:
        print(f"\n[PMI] Không tìm thấy file. Đặt file tại: {pmi_path}")

    # ── Load Interbank ────────────────────────────────────────────────────────
    combined_path = DATA / "interbank_overnight_daily.csv"
    if ibor_path.exists():
        print("\n[Interbank] Đang xử lý...")
        ibor_raw = load_series(ibor_path, "interbank_on")
        # Chi ghi de neu file combined chua ton tai hoac raw co nhieu rows hon
        if not combined_path.exists():
            ibor_raw.to_csv(combined_path, header=True)
            print(f"  Đã lưu: interbank_overnight_daily.csv")
        else:
            existing = pd.read_csv(combined_path, index_col=0, parse_dates=True)
            if len(ibor_raw) > len(existing):
                ibor_raw.to_csv(combined_path, header=True)
                print(f"  Đã cập nhật: interbank_overnight_daily.csv ({len(ibor_raw):,} rows)")
            else:
                print(f"  Giữ nguyên interbank_overnight_daily.csv ({len(existing):,} rows > {len(ibor_raw):,})")
                ibor_raw = pd.read_csv(combined_path, index_col=0, parse_dates=True).iloc[:, 0]
                ibor_raw.name = "interbank_on"
        loaded["interbank_on"] = ibor_raw
    elif combined_path.exists():
        print("\n[Interbank] Dùng file combined hiện có...")
        ibor_raw = pd.read_csv(combined_path, index_col=0, parse_dates=True).iloc[:, 0]
        ibor_raw.name = "interbank_on"
        loaded["interbank_on"] = ibor_raw
    else:
        print(f"\n[Interbank] Không tìm thấy file. Đặt file tại: {ibor_path}")

    if not loaded:
        print("\nKhông có file mới nào. Thoát.")
        sys.exit(0)

    # ── Đọc file merged hiện tại ──────────────────────────────────────────────
    daily_path   = DATA / "macro_daily_merged.csv"
    monthly_path = DATA / "macro_monthly_merged.csv"

    print("\n[Merge] Đọc file hiện tại...")
    daily   = pd.read_csv(daily_path,   index_col=0, parse_dates=True)
    monthly = pd.read_csv(monthly_path, index_col=0, parse_dates=True)
    daily.index.name = monthly.index.name = "date"

    print(f"  daily  : {daily.shape}  cols={daily.columns.tolist()}")
    print(f"  monthly: {monthly.shape} cols={monthly.columns.tolist()}")

    # ── Merge interbank (daily/monthly) ───────────────────────────────────────
    if "interbank_on" in loaded:
        ibor = loaded["interbank_on"].to_frame()
        # Xoa cot cu neu co de tranh duplicate
        if "interbank_on" in daily.columns:
            daily = daily.drop(columns=["interbank_on"])
        daily = daily.join(ibor, how="outer")
        # Cho monthly: resample ve cuoi thang
        if "interbank_on" in monthly.columns:
            monthly = monthly.drop(columns=["interbank_on"])
        ibor_m = ibor.resample("ME").last()
        monthly = monthly.join(ibor_m, how="outer")

    # ── Merge PMI (monthly only) ──────────────────────────────────────────────
    if "pmi" in loaded:
        pmi_m = loaded["pmi"].resample("ME").last().to_frame()
        # Loại bỏ cột pmi cũ nếu có
        if "pmi" in monthly.columns:
            monthly = monthly.drop(columns=["pmi"])
        monthly = monthly.join(pmi_m, how="outer")

    # ── Lưu lại ──────────────────────────────────────────────────────────────
    daily   = daily.sort_index()
    monthly = monthly.sort_index()

    daily.to_csv(daily_path)
    monthly.to_csv(monthly_path)

    print(f"\n[OK] macro_daily_merged.csv   -> {daily.shape[0]:,} dòng, {daily.shape[1]} cột: {daily.columns.tolist()}")
    print(f"[OK] macro_monthly_merged.csv -> {monthly.shape[0]:,} dòng, {monthly.shape[1]} cột: {monthly.columns.tolist()}")
    print("\nHoàn tất!")


if __name__ == "__main__":
    main()
