"""
Lap day khoang trong du lieu interbank (2015-nay) bang WorldBank lending rate.
VNIBOR ON (2013-2014) tu Investing.com giu nguyen, gan them proxy WB cho phan con thieu.

Note cho paper:
  - 2013-01 to 2014-12: VNIBOR Overnight (Investing.com/SBV)
  - 2015-01 to 2023-12: Vietnam lending interest rate (WorldBank FR.INR.LEND)
    interpolated linearly to monthly. Dung lam proxy vi khong co nguon mien phi.
"""
from __future__ import annotations
import sys, datetime as dt
from pathlib import Path

import pandas as pd
import requests

DATA  = Path(__file__).resolve().parent.parent / "data"
START = "2013-01-01"
END   = dt.date.today().isoformat()

HEADERS = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"}


def get_wb_lending_rate() -> pd.Series | None:
    """WorldBank FR.INR.LEND: Vietnam Lending interest rate (%)."""
    url = ("https://api.worldbank.org/v2/country/VN/indicator/FR.INR.LEND"
           "?format=json&per_page=50&date=2013:2025")
    try:
        r = requests.get(url, headers=HEADERS, timeout=20)
        if r.status_code != 200:
            return None
        data = r.json()
        if len(data) < 2 or not data[1]:
            return None
        rows = [(x["date"], x["value"]) for x in data[1] if x["value"] is not None]
        if not rows:
            return None
        s = pd.Series({int(y): v for y, v in rows}).sort_index()
        # Doi sang monthly cuoi nam -> interpolate
        s.index = pd.to_datetime([f"{y}-12-31" for y in s.index])
        s.index.name = "date"
        # Resample monthly, fill dau = dau chuoi, cuoi = cuoi chuoi
        monthly = s.resample("ME").interpolate(method="linear")
        monthly.name = "interbank_proxy_wb_lend"
        print(f"   WB FR.INR.LEND: {len(rows)} years ({rows[-1][0]}-{rows[0][0]}) "
              f"-> {len(monthly)} monthly rows")
        return monthly
    except Exception as e:
        print(f"   ERR: {e}")
        return None


def get_wb_real_rate() -> pd.Series | None:
    """WorldBank FR.INR.RINR: Real interest rate (%) — fallback."""
    url = ("https://api.worldbank.org/v2/country/VN/indicator/FR.INR.RINR"
           "?format=json&per_page=50&date=2013:2025")
    try:
        r = requests.get(url, headers=HEADERS, timeout=20)
        if r.status_code != 200:
            return None
        data = r.json()
        if len(data) < 2 or not data[1]:
            return None
        rows = [(x["date"], x["value"]) for x in data[1] if x["value"] is not None]
        if not rows:
            return None
        s = pd.Series({int(y): v for y, v in rows}).sort_index()
        s.index = pd.to_datetime([f"{y}-12-31" for y in s.index])
        s.index.name = "date"
        monthly = s.resample("ME").interpolate(method="linear")
        monthly.name = "interbank_proxy_wb_real"
        print(f"   WB FR.INR.RINR: {len(rows)} years -> {len(monthly)} monthly rows")
        return monthly
    except Exception as e:
        print(f"   ERR: {e}")
        return None


def main():
    # --- Load existing VNIBOR (2013-2014) ---
    real_path = DATA / "interbank_overnight_daily.csv"
    if not real_path.exists():
        print("interbank_overnight_daily.csv khong ton tai. Chay download_macro_data.py truoc.")
        sys.exit(1)

    real_df = pd.read_csv(real_path, index_col=0, parse_dates=True)
    real_df.index.name = "date"
    real_s = real_df["interbank_on"] if "interbank_on" in real_df.columns else real_df.iloc[:, 0]
    real_s.name = "interbank_on"
    print(f"Existing VNIBOR: {real_s.notna().sum():,} obs | "
          f"{real_s.index[0].date()} -> {real_s.index[-1].date()}")

    # --- Get WorldBank proxy ---
    print("\n[WorldBank] Lay lending rate Vietnam...")
    proxy = get_wb_lending_rate()
    if proxy is None:
        print("   Lending rate that bai, thu real rate...")
        proxy = get_wb_real_rate()
    if proxy is None:
        print("WorldBank ERR — khong the lay proxy. Dung data VNIBOR co san.")
        # Still merge existing data into merged files
    else:
        # Resample proxy to daily (linear)
        proxy_daily = proxy.resample("D").interpolate(method="linear")
        proxy_daily.name = "interbank_on"

        # Combine: thuc te VNIBOR co uu tien cao hon proxy
        combined = real_s.combine_first(proxy_daily)
        combined.name = "interbank_on"
        combined = combined.loc[START:END]

        notna_pct = combined.notna().mean()
        print(f"\nCombined: {combined.notna().sum():,}/{len(combined):,} non-null ({notna_pct:.1%})")
        print(f"  Range: {combined.dropna().index[0].date()} -> {combined.dropna().index[-1].date()}")

        # Luu file combined (KHONG de merge_manual_data.py ghi de)
        combined.to_csv(real_path, header=True)
        print(f"  Saved: {real_path.name}")

        # Luu file proxy rieng de document
        proxy.to_csv(DATA / "interbank_wb_proxy_monthly.csv", header=True)
        print(f"  Saved: interbank_wb_proxy_monthly.csv")

        # --- Truc tiep cap nhat macro merged files (KHONG dung subprocess) ---
        _update_macro_files(combined)


def _update_macro_files(ibor_combined: pd.Series) -> None:
    """Cap nhat interbank_on trong macro_daily_merged.csv va macro_monthly_merged.csv."""
    daily_path   = DATA / "macro_daily_merged.csv"
    monthly_path = DATA / "macro_monthly_merged.csv"

    if not daily_path.exists():
        print("  macro_daily_merged.csv khong ton tai, bo qua merge.")
        return

    print("\n>>> Cap nhat macro_*_merged.csv truc tiep...")
    daily   = pd.read_csv(daily_path,   index_col=0, parse_dates=True)
    monthly = pd.read_csv(monthly_path, index_col=0, parse_dates=True)
    daily.index.name = monthly.index.name = "date"

    # Replace hoac add interbank_on column
    ibor_frame = ibor_combined.to_frame()          # Series -> DataFrame
    ibor_frame.index.name = "date"

    # Daily: outer join de giu cac date moi tu interbank
    if "interbank_on" in daily.columns:
        daily = daily.drop(columns=["interbank_on"])
    daily = daily.join(ibor_frame, how="outer")
    daily = daily.sort_index()

    # Monthly: resample interbank de cuoi thang
    ibor_monthly = ibor_frame.resample("ME").last()
    if "interbank_on" in monthly.columns:
        monthly = monthly.drop(columns=["interbank_on"])
    monthly = monthly.join(ibor_monthly, how="outer")
    monthly = monthly.sort_index()

    daily.to_csv(daily_path)
    monthly.to_csv(monthly_path)

    nn_d = daily["interbank_on"].notna().sum()
    nn_m = monthly["interbank_on"].notna().sum()
    print(f"  daily  : {daily.shape}  | interbank_on non-null: {nn_d:,}/{len(daily):,} ({nn_d/len(daily):.1%})")
    print(f"  monthly: {monthly.shape} | interbank_on non-null: {nn_m:,}/{len(monthly):,} ({nn_m/len(monthly):.1%})")
    print("  Hoan tat!")


if __name__ == "__main__":
    main()
