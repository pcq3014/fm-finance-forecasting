"""
Tu dong tai PMI Vietnam + Interbank rate tu Investing.com API
roi goi merge_manual_data.py de ghep vao merged files.
"""
from __future__ import annotations
import sys, time, json, io, datetime as dt, re
from pathlib import Path
import pandas as pd
import requests

DATA = Path(__file__).resolve().parent.parent / "data"
DATA.mkdir(exist_ok=True)

START = "2013-01-01"
END   = dt.date.today().isoformat()

HEADERS_BASE = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                  "AppleWebKit/537.36 (KHTML, like Gecko) "
                  "Chrome/124.0.0.0 Safari/537.36",
    "Accept-Language": "vi-VN,vi;q=0.9,en;q=0.8",
}

# Session dùng chung — giữ cookies tự động
_SESSION: requests.Session | None = None


def _session() -> requests.Session:
    global _SESSION
    if _SESSION is None:
        _SESSION = requests.Session()
        _SESSION.headers.update(HEADERS_BASE)
        try:
            _SESSION.get("https://vn.investing.com/", timeout=15)
        except Exception:
            pass
    return _SESSION


def fetch_investing_chart(instrument_id: int, label: str) -> pd.Series | None:
    """
    Goi endpoint chart data cua Investing.com.
    instrument_id: so cuoi URL (e.g. vietnam-manufacturing-pmi-1210 -> 1210)
    """
    sess = _session()
    url = (
        f"https://api.investing.com/api/financialdata/{instrument_id}"
        f"/historical/chart/?period=MAX&startDate={START}&endDate={END}&pointscount=120"
    )
    extra = {
        "Accept": "application/json, text/javascript, */*; q=0.01",
        "Referer": "https://vn.investing.com/",
        "X-Requested-With": "XMLHttpRequest",
    }
    try:
        r = sess.get(url, headers=extra, timeout=20)
    except Exception as e:
        print(f"   Request loi: {e}")
        return None

    if r.status_code != 200:
        print(f"   HTTP {r.status_code}")
        return None
    try:
        data = r.json()
        rows = data.get("data", [])
        if not rows:
            print("   Khong co data trong response JSON.")
            return None
        df = pd.DataFrame(rows)
        ts  = pd.to_datetime(df[0], unit="ms")
        val = pd.to_numeric(df[4] if len(df.columns) > 4 else df[1], errors="coerce")
        s   = pd.Series(val.values, index=ts, name=label).dropna().sort_index()
        s.index.name = "date"
        return s
    except Exception as e:
        print(f"   Parse loi: {e}")
        return None


def fetch_investing_history_page(hist_url: str, label: str) -> pd.Series | None:
    """
    Scrape bang lich su tu trang .../historical-data (Investing.com).
    URL dang: https://vn.investing.com/rates-bonds/vietnam-interbank-rate-historical-data
    """
    sess = _session()
    try:
        r = sess.get(hist_url, timeout=20)
    except Exception as e:
        print(f"   Request loi: {e}")
        return None

    if r.status_code != 200:
        print(f"   HTTP {r.status_code}")
        return None

    # Tim JSON trong <script>
    match = re.search(r'"historicalData"\s*:\s*(\[.*?\])', r.text, re.S)
    if match:
        try:
            rows  = json.loads(match.group(1))
            dates = [pd.to_datetime(x.get("rowDate") or x.get("date"), dayfirst=True)
                     for x in rows]
            vals  = [float(str(x.get("last_close") or x.get("price", "")).replace(",", ""))
                     for x in rows]
            s = pd.Series(vals, index=dates, name=label).dropna().sort_index()
            s.index.name = "date"
            if len(s) > 5:
                return s
        except Exception as e:
            print(f"   JSON parse loi: {e}")

    # Fallback: read_html
    try:
        tables = pd.read_html(io.StringIO(r.text))
        for t in tables:
            date_col = next((c for c in t.columns if "date" in str(c).lower()), None)
            val_col  = next((c for c in t.columns
                             if any(k in str(c).lower()
                                    for k in ["price", "actual", "last", "value"])), None)
            if date_col and val_col:
                dates = pd.to_datetime(t[date_col], dayfirst=True, errors="coerce")
                vals  = pd.to_numeric(
                    t[val_col].astype(str).str.replace(",", ""), errors="coerce"
                )
                s = pd.Series(vals.values, index=dates, name=label).dropna().sort_index()
                s.index.name = "date"
                if len(s) > 5:
                    return s
    except Exception as e:
        print(f"   read_html loi: {e}")
    return None


# ── Instrument IDs / URLs ────────────────────────────────────────────────────
PMI_ID        = 1210
PMI_HIST_URL  = ("https://vn.investing.com/economic-calendar/"
                 "vietnam-manufacturing-pmi-1210")

IBOR_ID       = 14065
IBOR_HIST_URL = ("https://vn.investing.com/rates-bonds/"
                 "vietnam-interbank-rate-historical-data")


def get_pmi() -> pd.Series | None:
    print("[PMI] Dang tai tu Investing.com API...")
    s = fetch_investing_chart(PMI_ID, "pmi")
    if s is not None and len(s) > 10:
        return s
    print("[PMI] API that bai, thu scrape HTML...")
    return fetch_investing_history_page(PMI_HIST_URL, "pmi")


def get_interbank() -> pd.Series | None:
    print("[Interbank] Dang tai tu Investing.com API...")
    s = fetch_investing_chart(IBOR_ID, "interbank_on")
    if s is not None and len(s) > 10:
        return s
    print("[Interbank] API that bai, thu scrape HTML...")
    return fetch_investing_history_page(IBOR_HIST_URL, "interbank_on")


def main():
    pmi  = get_pmi()
    time.sleep(1)
    ibor = get_interbank()

    if pmi is None and ibor is None:
        print("\nKhong tai duoc du lieu tu dong.")
        print("Vui long tai thu cong theo huong dan trong merge_manual_data.py")
        sys.exit(1)

    if pmi is not None:
        out = DATA / "pmi_vietnam_raw.csv"
        pmi.to_csv(out, header=True)
        print(f"   Da luu {out.name}  ({len(pmi):,} dong)")

    if ibor is not None:
        out = DATA / "interbank_raw.csv"
        ibor.to_csv(out, header=True)
        print(f"   Da luu {out.name}  ({len(ibor):,} dong)")

    print("\n>>> Chay merge_manual_data.py ...")
    import subprocess, os
    result = subprocess.run(
        [sys.executable, str(Path(__file__).parent / "merge_manual_data.py")],
        env={**os.environ, "PYTHONIOENCODING": "utf-8", "PYTHONUTF8": "1"},
    )
    sys.exit(result.returncode)


if __name__ == "__main__":
    main()
