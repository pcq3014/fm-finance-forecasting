"""
================================================================================
 Vietnam Macro Features Downloader
================================================================================
 Mục tiêu: tự động tải 6 biến macro (theo cấu trúc 3.3 Macro Features)
   1. Foreign net flow (HoSE)        -> vnstock (FiinTrade public mirror)
   2. USD/VND (SBV / commercial)     -> Vietcombank API + FRED EXVNUS
   3. Interbank rate (SBV)           -> investpy / Investing.com mirror
   4. VIX                            -> Yahoo Finance (^VIX)
   5. PMI Vietnam                    -> Trading Economics scrape (HTML table)
   6. HSI return                     -> Yahoo Finance (^HSI)

 Khoảng thời gian: 2013-01-01  ->  hôm nay
 Tần suất xuất:    daily (raw) và monthly (resampled) cho mỗi biến

 Nguồn: tất cả các nguồn được trích xuất từ provider gốc/được chính phủ /
        tổ chức công bố (Cboe, Yahoo, FRED St.Louis Fed, S&P Global,
        SBV, HOSE/FiinTrade).

 Yêu cầu:
   pip install yfinance pandas pandas-datareader requests beautifulsoup4 \
               lxml openpyxl vnstock
================================================================================
"""

from __future__ import annotations
import os
import sys
import time
import io
import json
import datetime as dt
from pathlib import Path

import pandas as pd
import requests

START = "2013-01-01"
END   = dt.date.today().isoformat()

ROOT  = Path(__file__).resolve().parent.parent
DATA  = ROOT / "data"
DATA.mkdir(parents=True, exist_ok=True)

HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                  "AppleWebKit/537.36 (KHTML, like Gecko) "
                  "Chrome/124.0 Safari/537.36"
}


def _yf_close(raw: pd.DataFrame, col_name: str) -> pd.DataFrame:
    """Chuẩn hoá output yfinance: hỗ trợ cả MultiIndex (>= 0.2.x) lẫn flat columns."""
    if isinstance(raw.columns, pd.MultiIndex):
        raw.columns = raw.columns.droplevel(1)
    return raw[["Close"]].rename(columns={"Close": col_name})


# --------------------------------------------------------------------------
# 1. VIX — Yahoo Finance (^VIX)
# --------------------------------------------------------------------------
def get_vix() -> pd.DataFrame:
    """Daily VIX close from Yahoo Finance. Fallback: FRED VIXCLS."""
    print("[1/6] VIX  ...")
    try:
        import yfinance as yf
        raw = yf.download("^VIX", start=START, end=END, auto_adjust=False,
                          progress=False)
        df = _yf_close(raw, "vix")
    except Exception as e:
        print("   yfinance failed, falling back to FRED:", e)
        url = "https://fred.stlouisfed.org/graph/fredgraph.csv?id=VIXCLS"
        r   = requests.get(url, headers=HEADERS, timeout=60)
        df  = pd.read_csv(io.StringIO(r.text), parse_dates=["observation_date"])
        df  = df.rename(columns={"observation_date": "Date", "VIXCLS": "vix"})
        df  = df.set_index("Date")
    df.index.name = "date"
    df = df.loc[START:END].dropna()
    df.to_csv(DATA / "vix_daily.csv")
    print(f"   -> {DATA/'vix_daily.csv'}  ({len(df):,} rows)")
    return df


# --------------------------------------------------------------------------
# 2. HSI return — Yahoo Finance (^HSI)
# --------------------------------------------------------------------------
def get_hsi() -> pd.DataFrame:
    """Daily Hang Seng close + log return."""
    print("[2/6] HSI  ...")
    import yfinance as yf
    import numpy as np
    raw = yf.download("^HSI", start=START, end=END, auto_adjust=False,
                      progress=False)
    df = _yf_close(raw, "hsi_close")
    df["hsi_logret"] = np.log(df["hsi_close"] / df["hsi_close"].shift(1))
    df.index.name   = "date"
    df = df.dropna()
    df.to_csv(DATA / "hsi_daily.csv")
    print(f"   -> {DATA/'hsi_daily.csv'}  ({len(df):,} rows)")
    return df


# --------------------------------------------------------------------------
# 3. USD/VND — kết hợp (a) FRED EXVNUS (monthly, IMF) và
#                       (b) Vietcombank rate (daily) hoặc
#                       (c) Yahoo VND=X
# --------------------------------------------------------------------------
def get_usdvnd() -> pd.DataFrame:
    """USD/VND daily.
       Nguồn ưu tiên: Yahoo `VND=X` (interbank quote, daily).
       Nguồn xác thực bổ sung: FRED EXVNUS (IMF Rate, monthly).
       Để khớp với SBV "tỷ giá trung tâm" dùng từ 2016-01-04 — bạn có thể
       thay bằng file scrape SBV nếu cần (xem hướng dẫn ở docs/README.md)."""
    print("[3/6] USD/VND ...")
    import yfinance as yf
    raw = yf.download("VND=X", start=START, end=END, auto_adjust=False,
                      progress=False)
    df = _yf_close(raw, "usdvnd")
    df.index.name = "date"
    df = df.dropna()
    df.to_csv(DATA / "usdvnd_daily.csv")

    # Bổ sung: FRED monthly  ----------------------------------
    try:
        url = "https://fred.stlouisfed.org/graph/fredgraph.csv?id=EXVNUS"
        r = requests.get(url, headers=HEADERS, timeout=60)
        m  = pd.read_csv(io.StringIO(r.text), parse_dates=["observation_date"])
        m  = m.rename(columns={"observation_date": "date",
                               "EXVNUS": "usdvnd_imf_monthly"})
        m  = m.set_index("date").loc[START:END]
        m.to_csv(DATA / "usdvnd_monthly_fred.csv")
        print(f"   -> {DATA/'usdvnd_monthly_fred.csv'}  ({len(m):,} rows)")
    except Exception as e:
        print("   FRED EXVNUS skipped:", e)

    print(f"   -> {DATA/'usdvnd_daily.csv'}  ({len(df):,} rows)")
    return df


# --------------------------------------------------------------------------
# 4. Interbank rate (VNIBOR) — WorldBank primary + Investing.com fallback
# --------------------------------------------------------------------------
def get_interbank() -> pd.DataFrame:
    """
    Nguon chinh: WorldBank FR.INR.LEND (Vietnam lending rate, annual, official).
    Nguon phu:   Investing.com VNIBOR ON (2013-2014, daily, SBV data mirror).
    Chu y paper: 2013-2014 = VNIBOR ON (Investing.com/SBV);
                 2015-2023 = lending rate WB (annual -> monthly interpolation).
    """
    print("[4/6] Interbank rate ...")
    out = DATA / "interbank_overnight_daily.csv"

    # --- Buoc 1: WorldBank lending rate (verified, official) ---
    wb_series = None
    try:
        url = ("https://api.worldbank.org/v2/country/VN/indicator/FR.INR.LEND"
               "?format=json&per_page=50&date=2013:2025")
        r = requests.get(url, headers=HEADERS, timeout=20)
        if r.status_code == 200:
            data = r.json()
            if len(data) > 1 and data[1]:
                rows = [(x["date"], x["value"]) for x in data[1]
                        if x["value"] is not None]
                if rows:
                    import numpy as np
                    s = pd.Series({int(y): v for y, v in rows}).sort_index()
                    s.index = pd.to_datetime([f"{y}-12-31" for y in s.index])
                    s.index.name = "date"
                    wb_series = s.resample("ME").interpolate(method="linear")
                    wb_series.name = "interbank_on"
                    print(f"   WorldBank FR.INR.LEND: {len(rows)} years")
    except Exception as e:
        print(f"   WorldBank failed: {e}")

    # --- Buoc 2: Investing.com VNIBOR ON (neu co file cu) ---
    investing_series = None
    raw_path = DATA / "interbank_raw.csv"
    if raw_path.exists():
        try:
            raw = pd.read_csv(raw_path, thousands=",", encoding="utf-8-sig")
            raw.columns = raw.columns.str.strip()
            date_col = next((c for c in raw.columns if "date" in c.lower()), raw.columns[0])
            val_col  = next((c for c in raw.columns if "price" in c.lower()), raw.columns[1])
            dates  = pd.to_datetime(raw[date_col], errors="coerce")
            values = pd.to_numeric(raw[val_col].astype(str).str.replace(",", ""),
                                   errors="coerce")
            investing_series = pd.Series(values.values, index=dates,
                                         name="interbank_on").dropna().sort_index()
            investing_series = investing_series.loc[START:END]
            print(f"   Investing.com VNIBOR: {len(investing_series):,} rows "
                  f"({investing_series.index[0].date()} -> {investing_series.index[-1].date()})")
        except Exception as e:
            print(f"   interbank_raw.csv read failed: {e}")

    # --- Ket hop: investing.com co uu tien (thuc te), WB lam proxy cho khoang trong ---
    if wb_series is not None or investing_series is not None:
        wb_daily = None
        if wb_series is not None:
            wb_daily = wb_series.resample("D").interpolate(method="linear")
            wb_daily.name = "interbank_on"

        if investing_series is not None and wb_daily is not None:
            combined = investing_series.combine_first(wb_daily)
        elif investing_series is not None:
            combined = investing_series
        else:
            combined = wb_daily

        combined = combined.loc[START:END]
        df = combined.to_frame()
        df.index.name = "date"
        df.to_csv(out)
        print(f"   -> {out}  ({df['interbank_on'].notna().sum():,}/{len(df):,} non-null)")
        return df

    print("   Khong lay duoc interbank. Chay _fill_interbank_proxy.py hoac tai tay.")
    print(f"   Luu vao: {out}")
    return pd.DataFrame()


# --------------------------------------------------------------------------
# 5. PMI Vietnam — Trading Economics (HTML page)
# --------------------------------------------------------------------------
def get_pmi() -> pd.DataFrame:
    """Trading Economics chỉ cho xem ~10 năm gần nhất ở mức free.
       Phần history đầy đủ (2011+) bằng cách dùng API 'investpy' hoặc
       tải Excel official từ S&P Global press release.
       Script này thử investpy trước; nếu không có thì scrape table."""
    print("[5/6] Vietnam PMI ...")
    out = DATA / "pmi_vietnam_monthly.csv"
    try:
        import investpy
        df = investpy.economic_calendar(
            countries=["vietnam"],
            from_date=pd.to_datetime(START).strftime("%d/%m/%Y"),
            to_date=pd.to_datetime(END).strftime("%d/%m/%Y"),
            categories=["confidence"]
        )
        df = df[df["event"].str.contains("Manufacturing PMI", case=False, na=False)]
        df = df[["date", "actual"]].rename(columns={"actual": "pmi"})
        df["date"] = pd.to_datetime(df["date"], dayfirst=True)
        df = df.set_index("date").sort_index()
        df.to_csv(out)
        print(f"   -> {out}  ({len(df):,} rows)")
        return df
    except Exception as e:
        print("   investpy failed, fallback to HTML scrape:", e)

    try:
        url = "https://tradingeconomics.com/vietnam/manufacturing-pmi"
        r   = requests.get(url, headers=HEADERS, timeout=30)
        tables = pd.read_html(r.text)
        df  = tables[0]
        df.to_csv(out)
        print(f"   -> {out}  (HTML scrape, please verify column names)")
        return df
    except Exception as e:
        print("   HTML scrape failed:", e)
        print("   *** Hãy tải Excel từ S&P Global press release thủ công.")
        return pd.DataFrame()


# --------------------------------------------------------------------------
# 6. Foreign net flow (HoSE)
# --------------------------------------------------------------------------
def get_foreign_flow() -> pd.DataFrame:
    """
    HOSE foreign net flow — thu tu dong, neu that bai thi huong dan tai tay.
    - Neu file da ton tai (tu lan chay truoc): dung luon.
    - Uu tien: vnstock.api.trading.Trading (moi); fallback: vnstock cu.
    - Thu cong: https://www.hsx.vn/Modules/Rsde/Report/ForeignTradingReportIndex
    """
    print("[6/6] HOSE foreign net flow ...")
    out = DATA / "foreign_net_flow_hose_daily.csv"

    if out.exists():
        df = pd.read_csv(out, index_col=0, parse_dates=True)
        print(f"   File da ton tai: {len(df):,} rows. Dung luon.")
        return df

    # Thu vnstock API moi
    try:
        from vnstock.api.trading import Trading
        t = Trading(symbol="VNM", source="VCI")
        df = t.foreign_trade(start=START, end=END)
        if not df.empty:
            df.to_csv(out)
            print(f"   -> {out}  ({len(df):,} rows via vnstock.api.trading)")
            return df
    except Exception as e:
        print(f"   vnstock.api.trading failed: {type(e).__name__}")

    print("   *** Can tai thu cong:")
    print("   1. Vao: https://www.hsx.vn/Modules/Rsde/Report/ForeignTradingReportIndex")
    print("   2. Chon VNINDEX, export tung doan 5 nam")
    print("   3. Luu vao:", out)
    return pd.DataFrame()


# ==========================================================================
# Main pipeline
# ==========================================================================
def main():
    vix    = get_vix()
    hsi    = get_hsi()
    fx     = get_usdvnd()
    ibor   = get_interbank()
    pmi    = get_pmi()
    flow   = get_foreign_flow()

    # Merge daily features ------------------------------------------------
    daily = vix.join(hsi, how="outer") \
               .join(fx, how="outer")
    if not ibor.empty:
        daily = daily.join(ibor, how="outer")
    if not flow.empty:
        daily = daily.join(flow, how="outer")
    daily = daily.sort_index()
    daily.to_csv(DATA / "macro_daily_merged.csv")
    print(f"\nMerged daily file -> {DATA/'macro_daily_merged.csv'}"
          f"  ({len(daily):,} rows, {daily.shape[1]} cols)")

    # Resample to monthly (end-of-month) ---------------------------------
    monthly = daily.resample("ME").last()
    if not pmi.empty:
        pmi_m = pmi.resample("ME").last()
        monthly = monthly.join(pmi_m, how="outer")
    monthly.to_csv(DATA / "macro_monthly_merged.csv")
    print(f"Merged monthly file -> {DATA/'macro_monthly_merged.csv'}"
          f"  ({len(monthly):,} rows)")


if __name__ == "__main__":
    main()
