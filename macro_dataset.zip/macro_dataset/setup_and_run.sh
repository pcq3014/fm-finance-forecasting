#!/usr/bin/env bash
# Quick setup — chạy trên Linux/macOS/WSL
set -e

echo ">> Cài đặt thư viện cần thiết"
python3 -m pip install --upgrade pip
python3 -m pip install yfinance pandas pandas-datareader requests \
    beautifulsoup4 lxml openpyxl vnstock investpy

echo ">> Tải dữ liệu (mất 1–3 phút tùy mạng)"
python3 scripts/download_macro_data.py

echo ">> Hoàn tất. Kiểm tra thư mục data/"
ls -la data/
