# Vietnam Macro Features — Bộ dữ liệu nghiên cứu (2013 → hiện tại)

Bộ pipeline tự động tải 6 biến macro tương ứng với mục **3.3 Macro Features**.

## 1. Cấu trúc thư mục
```
macro_dataset/
├── scripts/
│   └── download_macro_data.py   # script chính, chạy 1 lệnh
├── data/                        # CSV output (sẽ được tạo sau khi chạy)
│   ├── vix_daily.csv
│   ├── hsi_daily.csv
│   ├── usdvnd_daily.csv
│   ├── usdvnd_monthly_fred.csv
│   ├── interbank_overnight_daily.csv
│   ├── pmi_vietnam_monthly.csv
│   ├── foreign_net_flow_hose_daily.csv
│   ├── macro_daily_merged.csv
│   └── macro_monthly_merged.csv
└── docs/
    └── README.md                # file này
```

## 2. Cài đặt và chạy
```bash
# Khuyến nghị Python 3.10+
pip install yfinance pandas pandas-datareader requests beautifulsoup4 \
            lxml openpyxl vnstock investpy

cd scripts
python download_macro_data.py
```
Script sẽ in tiến trình của 6 biến và tạo các file CSV trong thư mục `data/`.
Khoảng thời gian mặc định: **2013-01-01 → hôm nay**.

## 3. Mapping nguồn dữ liệu (đầy đủ trích dẫn cho academic paper)

| # | Biến trong paper | File output | Nguồn gốc (citation) | Provider script gọi |
|---|---|---|---|---|
| 1 | Foreign net flow (HoSE) | `foreign_net_flow_hose_daily.csv` | Sở Giao dịch Chứng khoán TP.HCM (HOSE), `hsx.vn/Modules/Rsde/Report/ForeignTradingReportIndex` | vnstock → FiinTrade public API (mirror số liệu HOSE) |
| 2 | USD/VND | `usdvnd_daily.csv`, `usdvnd_monthly_fred.csv` | Ngân hàng Nhà nước Việt Nam (SBV), `dttktt.sbv.gov.vn/TyGia/faces/TyGia.jspx` (tỷ giá trung tâm từ 2016-01-04, trước đó là tỷ giá bình quân liên ngân hàng) | Yahoo Finance `VND=X` + IMF qua FRED `EXVNUS` |
| 3 | Interbank rate | `interbank_overnight_daily.csv` | SBV, `dttktt.sbv.gov.vn/webcenter/portal/en/home/rm/ir` | vnstock (ON rate) |
| 4 | VIX | `vix_daily.csv` | Cboe Global Markets, `cboe.com/tradable-products/vix/vix-historical-data` | Yahoo Finance `^VIX` (fallback FRED `VIXCLS`) |
| 5 | PMI Vietnam | `pmi_vietnam_monthly.csv` | S&P Global Vietnam Manufacturing PMI (Cimigo thu thập từ 2013), `pmi.spglobal.com` | Trading Economics scrape / investpy |
| 6 | HSI return | `hsi_daily.csv` | Hang Seng Indexes Co. Ltd, `hsi.com.hk` | Yahoo Finance `^HSI` |

## 4. Lưu ý phương pháp luận quan trọng (BẮT BUỘC ĐỌC trước khi viết bài)

### 4.1 USD/VND — chuyển chế độ tỷ giá
- **Trước 04/01/2016:** SBV dùng *Tỷ giá bình quân liên ngân hàng* (interbank average rate) — biên độ ±1%.
- **Từ 04/01/2016 đến nay:** SBV dùng *Tỷ giá trung tâm* (central reference rate) — biên độ ±5% (mở rộng từ ±3% năm 2022).
- Yahoo `VND=X` phản ánh tỷ giá thị trường liên ngân hàng (gần với rate thực giao dịch của các NHTM); đây là proxy tốt cho cả giai đoạn nếu bạn cần một series nhất quán. Nếu paper yêu cầu rate "official" của SBV, hãy dùng `usdvnd_monthly_fred.csv` (IMF Rate).

### 4.2 PMI — đổi nhà bảo trợ
- 04/2011 – 03/2016: do **HSBC/Markit**.
- 04/2016 – 06/2022: do **Nikkei/IHS Markit**.
- 07/2022 – nay: do **S&P Global**.
- Toàn bộ giai đoạn dùng cùng phương pháp PMI (NTC Economics → IHS Markit → S&P Global), nên series **vẫn liên tục, không cần điều chỉnh**, nhưng nên ghi chú trong section "Data".

### 4.3 Interbank rate — chọn kỳ hạn
SBV công bố nhiều kỳ hạn (ON, 1W, 2W, 1M, 3M, 6M). Khuyến nghị:
- **Overnight (ON)**: phản ánh thanh khoản hệ thống (nhạy nhất).
- **1 tuần** hoặc **1 tháng**: nếu nghiên cứu thiên về policy stance.
Script mặc định dùng **ON**.

### 4.4 HoSE foreign net flow
- Đơn vị: VND (tỷ hoặc nghìn tỷ; check column header).
- Net = Buy − Sell, theo phiên (daily).
- Nếu bạn cần phân rã theo cổ phiếu, dùng `vn.market.foreign_trading(symbol="VNM")` thay vì `"VNINDEX"`.

### 4.5 HSI return
- Tính theo log return: `r_t = ln(P_t / P_{t-1})`. Đã được tính sẵn ở column `hsi_logret`.
- Vì HSI và HoSE chênh lệch múi giờ ~1h, nên trong empirical test bạn có thể cần lag 1 phiên (xem các paper Wang et al. 2018, Le & Tran 2019).

## 5. Đồng bộ tần suất & merge

Script tự động tạo 2 file tổng:

- `macro_daily_merged.csv` — outer-join tất cả series daily (VIX, HSI, USD/VND, interbank, foreign flow). Hàng có `NaN` ở các phiên không trùng (VD: VIX không có ngày HOSE giao dịch).
- `macro_monthly_merged.csv` — resample về cuối tháng (`.resample("M").last()`), gộp thêm PMI (đã monthly).

Trong nghiên cứu thường dùng **monthly** để đảm bảo PMI có giá trị; nếu daily, bạn nên forward-fill PMI hoặc bỏ.

## 6. Trích dẫn (BibTeX gợi ý)

```bibtex
@misc{cboe_vix,
  title  = {Cboe Volatility Index (VIX) Historical Data},
  author = {{Cboe Global Markets}},
  url    = {https://www.cboe.com/tradable-products/vix/vix-historical-data},
  note   = {Accessed via Yahoo Finance ticker \texttt{\^{}VIX}}
}

@misc{spglobal_pmi_vn,
  title  = {S\&P Global Vietnam Manufacturing PMI},
  author = {{S\&P Global}},
  url    = {https://www.pmi.spglobal.com/Public/Home/PressRelease},
  note   = {Survey conducted by Cimigo Vietnam since 2013}
}

@misc{hsi_index,
  title  = {Hang Seng Index — Daily Closing Prices},
  author = {{Hang Seng Indexes Company Limited}},
  url    = {https://www.hsi.com.hk/eng/indexes/all-indexes/hsi}
}

@misc{sbv_fx,
  title  = {USD/VND Central Reference Rate},
  author = {{State Bank of Vietnam}},
  url    = {https://dttktt.sbv.gov.vn/TyGia/faces/TyGia.jspx}
}

@misc{sbv_ibor,
  title  = {Vietnam Interbank Offered Rate (VNIBOR)},
  author = {{State Bank of Vietnam}},
  url    = {https://dttktt.sbv.gov.vn/webcenter/portal/en/home/rm/ir}
}

@misc{hose_foreign,
  title  = {Foreign Investor Trading Statistics},
  author = {{Ho Chi Minh Stock Exchange (HOSE)}},
  url    = {https://www.hsx.vn/Modules/Rsde/Report/ForeignTradingReportIndex}
}
```

## 7. Khi script báo lỗi

| Trường hợp | Cách xử lý |
|---|---|
| `vnstock` không cài được hoặc đổi API | Tải tay từ Investing.com (`Vietnam Interbank Rate`) hoặc cào `s.cafef.vn/Ajax/PageNew/DataHistory/...` cho foreign flow |
| `yfinance` lỗi rate-limit | Đợi 5 phút rồi chạy lại; hoặc thêm `session=requests.Session()` |
| PMI thiếu dữ liệu cũ | Lấy bản Excel official trong từng press release của S&P Global theo tháng (link cuối mỗi release) |
| SBV chặn scrape | Dùng nguồn mirror CEIC / Trading Economics; ghi rõ trong paper là "data sourced from CEIC, originally reported by SBV" |

## 8. Liên hệ / cập nhật
Script đã được thiết kế modular — mỗi biến là 1 hàm `get_xxx()` riêng biệt. Bạn có thể chạy từng hàm riêng nếu chỉ cần update một biến.
